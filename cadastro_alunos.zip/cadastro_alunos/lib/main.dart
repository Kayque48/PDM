import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

void main() async {
  // Inicialização do Flutter e do Firebase
 void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  try {
    await Firebase.initializeApp();
    print("Firebase inicializado com sucesso!");
  } catch (e) {
    print("Erro ao inicializar Firebase: $e");
  }

  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: CadastroAlunos(),
  ));
}
}

// ----------- TELA PRINCIPAL (CADASTRO E LISTA) -----------

class CadastroAlunos extends StatefulWidget {
  @override
  State<CadastroAlunos> createState() => _CadastroAlunosState();
}

class _CadastroAlunosState extends State<CadastroAlunos> {
  TextEditingController nomeController = TextEditingController();
  TextEditingController idadeController = TextEditingController();
  TextEditingController cursoController = TextEditingController();

  // Função para salvar o aluno no Firestore
  void cadastrarAluno() async {
    String nome = nomeController.text;
    String idade = idadeController.text;
    String curso = cursoController.text;

    // Validação de campos vazios
    if (nome.isEmpty || idade.isEmpty || curso.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Preencha todos os campos!")),
      );
      return;
    }

    // Gravação no Cloud Firestore
    await FirebaseFirestore.instance.collection("alunos").add({
      "nome": nome,
      "idade": int.parse(idade),
      "curso": curso,
    });

    // Limpar os campos do formulário
    nomeController.clear();
    idadeController.clear();
    cursoController.clear();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Aluno cadastrado com sucesso!")),
    );
  }

  // Caixa de diálogo para confirmar a exclusão
  void confirmarExclusao(String docId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Confirmar Exclusão"),
        content: Text("Deseja realmente excluir este aluno?"),
        actions: [
          TextButton(
            child: Text("CANCELAR"),
            onPressed: () => Navigator.pop(context),
          ),
          ElevatedButton(
            child: Text("EXCLUIR"),
            onPressed: () async {
              await FirebaseFirestore.instance.collection("alunos").doc(docId).delete();
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Cadastro de Alunos", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: nomeController,
              decoration: InputDecoration(labelText: "Nome"),
            ),
            TextField(
              controller: idadeController,
              decoration: InputDecoration(labelText: "Idade"),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: cursoController,
              decoration: InputDecoration(labelText: "Curso"),
            ),
            SizedBox(height: 12),
            ElevatedButton(
              child: Text("Cadastrar Aluno"),
              onPressed: cadastrarAluno,
            ),
            Divider(height: 30, thickness: 2),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection("alunos").snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }

                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(child: Text("Nenhum aluno cadastrado."));
                  }

                  List<QueryDocumentSnapshot> alunos = snapshot.data!.docs;

                  return ListView.builder(
                    itemCount: alunos.length,
                    itemBuilder: (context, index) {
                      var aluno = alunos[index];
                      String docId = aluno.id;
                      String nome = aluno["nome"];
                      String idade = aluno["idade"].toString();
                      String curso = aluno["curso"];

                      return Card(
                        child: ListTile(
                          title: Text(nome),
                          subtitle: Text("$idade anos - $curso"),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(Icons.edit, color: Colors.blue),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => DetalheContato(
                                        docId: docId,
                                        nome: nome,
                                        idade: idade,
                                        curso: curso,
                                      ),
                                    ),
                                  );
                                },
                              ),
                              IconButton(
                                icon: Icon(Icons.delete, color: Colors.red),
                                onPressed: () => confirmarExclusao(docId),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ----------- TELA 2 (EDIÇÃO DE ALUNO) -----------

class DetalheContato extends StatefulWidget {
  final String docId;
  final String nome;
  final String idade;
  final String curso;

  DetalheContato({
    required this.docId,
    required this.nome,
    required this.idade,
    required this.curso,
  });

  @override
  State<DetalheContato> createState() => _DetalheContatoState();
}

class _DetalheContatoState extends State<DetalheContato> {
  late TextEditingController nomeEditController;
  late TextEditingController idadeEditController;
  late TextEditingController cursoEditController;

  @override
  void initState() {
    super.initState();
    nomeEditController = TextEditingController(text: widget.nome);
    idadeEditController = TextEditingController(text: widget.idade);
    cursoEditController = TextEditingController(text: widget.curso);
  }

  void atualizarAluno() async {
    await FirebaseFirestore.instance.collection("alunos").doc(widget.docId).update({
      "nome": nomeEditController.text,
      "idade": int.parse(idadeEditController.text),
      "curso": cursoEditController.text,
    });

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Editar Aluno", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.deepPurple,
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: nomeEditController,
              decoration: InputDecoration(labelText: "Nome"),
            ),
            TextField(
              controller: idadeEditController,
              decoration: InputDecoration(labelText: "Idade"),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: cursoEditController,
              decoration: InputDecoration(labelText: "Curso"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              child: Text("Salvar Alterações"),
              onPressed: atualizarAluno,
            ),
            TextButton(
              child: Text("Voltar", style: TextStyle(color: Colors.blue)),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}